// document.getElementById('nevigateToSendMail').addEventListener('click', function () {

//     window.location.href = '../create-events-send-emails.html';
// });